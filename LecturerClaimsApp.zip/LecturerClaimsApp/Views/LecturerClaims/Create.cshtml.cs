using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LecturerClaimsApp.Views.LecturerClaims
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
